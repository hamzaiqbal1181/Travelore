import React from "react";
import PlacesCard from "./PlacesCard";
import Img1 from "../../assets/places/fort.jpg";
import Img2 from "../../assets/places/Minar-e-Pakistan.jpg";
import Img3 from "../../assets/places/mosque.jpg";
import Img4 from "../../assets/places/shalimar.jpg";
import Img5 from "../../assets/places/sheesh.jpg";
import Img6 from "../../assets/places/wazir.jpg";
import Img7 from "../../assets/places/railway.jpg";
import Img8 from "../../assets/places/zoo.jpg";

const PlacesData = [
  {
    img: Img1,
    title: "Lahore Fort",
    location: "Lahore",
    description: "lorem ipsum dolor sit amet consectetur adipisicing elit .",
    type: "Historical",
  },

  {
    img: Img2,
    title: "Minar-e-Pakistan",
    location: "Lahore",
    description: "lorem ipsum dolor sit amet consectetur adipisicing elit.",
    type: "Historical",
  },

  {
    img: Img3,
    title: "Badshahi Mosque",
    location: "Lahore",
    description: "lorem ipsum dolor sit amet consectetur adipisicing elit.",
    type: "Historical",
  },

  {
    img: Img4,
    title: "Shalimar Garden",
    location: "Lahore",
    description: "lorem ipsum dolor sit amet consectetur adipisicing elit.",
    type: "Historical",
  },

  {
    img: Img5,
    title: "Sheesh Mehal",
    location: "Lahore",
    description: "lorem ipsum dolor sit amet consectetur adipisicing elit.",
    type: "Historical",
  },

  {
    img: Img6,
    title: "Wazir Khan Mosque",
    location: "Lahore",
    description: "lorem ipsum dolor sit amet consectetur adipisicing elit.",
    type: "Historical",
  },

  {
    img: Img7,
    title: "Railway Station",
    location: "Lahore",
    description: "lorem ipsum dolor sit amet consectetur adipisicing elit.",
    type: "Historical",
  },

  {
    img: Img8,
    title: "Lahore Zoo",
    location: "Lahore",
    description: "lorem ipsum dolor sit amet consectetur adipisicing elit.",
    type: "Historical",
  },
];

const Places = () => {
  return (
    <>
      <div className="bg-gray-50 py-10">
        <div className="container">
          <h1 className="my-8 ml-10 border-l-8 border-sky-700 py-2 pl-2 text-3xl font-bold">
            Places to Visit
          </h1>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
            {PlacesData.map((item, index) => (
              <PlacesCard key={index} {...item} />
            ))}
          </div>
        </div>
      </div>
    </>
  );
};

export default Places;
