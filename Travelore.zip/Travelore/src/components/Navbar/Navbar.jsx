import React, { useState } from "react";
import { Form, Link, NavLink } from "react-router-dom";
import LogoImg from "../../assets/logo.png";
import { HiMenuAlt3, HiMenuAlt1 } from "react-icons/hi";
import ResponsiveMenu from "./ResponsiveMenu";

export const NavbarLinks = [
  {
    name: "Home",
    link: "/",
  },
  {
    name: "Places",
    link: "/places",
  },
  {
    name: "Blogs",
    link: "/blogs",
  },
  {
    name: "About",
    link: "/about",
  },
];

const Navbar = () => {
  const [showMenu, setShowMenu] = useState(false);
  const toggleMenu = () => {
    setShowMenu(!showMenu);
  };
  return (
    <>
      <div className="fixed top-0 right-0 w-full bg-white text-black shadow-md z-[99999]">
        <div className="from-sky-200 to-sky-500 bg-gradient-to-r text-white">
          <div className="container py-[2px] sm:block hidden">
            <div className="flex justify-between py-[2px] px-[2px]">
              <p className="">Travelore</p>
              <p>Hidden Gem of Lahore</p>
            </div>
          </div>
        </div>
        <div className="container py-3 sm:py-0">
          <div className="flex justify-between items-center">
            {/* logo section */}
            <div>
              <Link to="/" onClick={() => window.scrollTo(0, 0)}>
                <img src={LogoImg} alt="" className="h-16" />
              </Link>
            </div>
            {/* Dextop Navlinks section */}
            <div className="hidden md:block">
              <ul className="flex items-center gap-8">
                <li className="py-4">
                  <NavLink
                    to="/"
                    className="text-black hover:underline underline-offset-4 active:text-sky-900"
                    activeClassName="text-sky-900"
                    onClick={() => window.scrollTo(0, 0)}
                  >
                    Home
                  </NavLink>
                </li>
                <li className="py-4">
                  <NavLink
                    to="/places"
                    className="text-black hover:underline underline-offset-4 active:text-sky-900"
                    activeClassName="text-sky-900"
                    onClick={() => window.scrollTo(0, 0)}
                  >
                    Places
                  </NavLink>
                </li>
                <li className="py-4">
                  <NavLink
                    to="/blogs"
                    className="text-black hover:underline underline-offset-4 active:text-sky-900"
                    activeClassName="text-sky-900"
                    onClick={() => window.scrollTo(0, 0)}
                  >
                    Blogs
                  </NavLink>
                </li>
                <li className="py-4">
                  <NavLink
                    to="/about"
                    className="text-black hover:underline underline-offset-4 active:text-sky-900"
                    activeClassName="text-sky-900"
                    onClick={() => window.scrollTo(0, 0)}
                  >
                    About
                  </NavLink>
                </li>
              </ul>
            </div>
            {/* Sign-in button */}
            <div className="flex items-center gap-4">
              <button className="bg-sky-200 text-black px-3 py-1 rounded-full hover:bg-sky-500">
                {" "}
                Sign-in
              </button>
              {/* Mobile Hamburger Menu */}
              <div className="md:hidden block">
                {showMenu ? (
                  <HiMenuAlt1
                    onClick={toggleMenu}
                    className="cursor-pointer transition-all
                            size={30}"
                  />
                ) : (
                  <HiMenuAlt3
                    onClick={toggleMenu}
                    className="cursor-pointer transition-all
                            size={30}"
                  />
                )}
                {}
              </div>
            </div>
          </div>
        </div>
        <ResponsiveMenu setShowMenu={setShowMenu} showMenu={showMenu} />
      </div>
    </>
  );
};

export default Navbar;
