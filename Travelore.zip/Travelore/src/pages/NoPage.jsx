import React from "react";

const NoPage = () => {
  return (
    <>
      <div></div>
    </>
  );
};

export default NoPage;
