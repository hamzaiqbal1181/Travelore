import React from "react";
import Location from "../components/Location/Location";
const About = () => {
  return (
    <>
      <div className="container pt-14 px-12 ">
        <div className="py-10">
          <h1 className="my-8 border-l-8 border-blue-500 py-2 pl-2 text-3xl font-bold">
            About us
          </h1>
          <p>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Hic,
            dolore. Voluptatum repellat rerum at commodi quisquam qui
            voluptatibus ullam consectetur quasi recusandae? Totam, vitae
            quidem. Accusantium earum aspernatur, minima repudiandae tempora
            commodi inventore error numquam consectetur magnam quidem fugiat sed
            quo, at minus a? Amet labore ipsam at consectetur et atque unde
            sapiente quia fugiat, beatae hic aperiam mollitia ducimus.
          </p>
          <br />
          <p>
            Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ducimus
            fuga dolores harum consequuntur aperiam, doloribus, odit laudantium
            eum inventore pariatur repellat iure, hic cumque deleniti
            necessitatibus assumenda repudiandae dicta modi. Quisquam odit at
            in, possimus blanditiis ipsa eaque! Accusamus, vel!
          </p>
        </div>
      </div>
      <Location />
    </>
  );
};

export default About;
